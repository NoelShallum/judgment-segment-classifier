"""Read a judgment as ordered token packs. Capture each sentence's native final FFN input and prototype scores."""
import argparse
import gzip
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer

HERE=Path(__file__).resolve().parent
REMOTE=Path('/content/reviewer2')
MODEL=REMOTE/'qwen'
ROLES=[
    'None. Court header, case number, names, citation, formatting, quoted material or incidental text that the judgment does not assign to a substantive rhetorical role.',
    'Facts. Background events, factual allegations, procedural history or the sequence of what happened in this case.',
    'Issue. The question of law or fact that this court must decide or resolve in the present case.',
    'Petitioner argument. The submission, contention or request of counsel for the appellant, applicant or petitioner.',
    'Respondent argument. The opposing submission, contention or defense of counsel for the respondent or the other party.',
    'Reasoning. The court evaluates evidence, interprets a statute or precedent, applies the law and gives its reasons for a conclusion.',
    'Decision. The court states its final ruling, allows or dismisses a petition, issues directions or orders a remedy.',
]
LIMIT=384
OVERLAP=64
BATCH=16

def verify_t4():
    actual=subprocess.check_output(['nvidia-smi','--query-gpu=name','--format=csv,noheader'],text=True).strip()
    assert actual in {'Tesla T4','NVIDIA T4','T4'} and torch.cuda.get_device_name(0) in {'Tesla T4','NVIDIA T4','T4'}
    return actual

def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def load_model():
    assert sha(MODEL/'model.safetensors')=='0437e45c94563b09e13cb7a64478fc406947a93cb34a7e05870fc8dcd48e23fd'
    m=AutoModel.from_pretrained(MODEL,local_files_only=True,torch_dtype=torch.float16,attn_implementation='sdpa').eval().requires_grad_(False).cuda()
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
    tail=m.layers[-1].mlp.down_proj
    tail.float()
    tail.register_forward_pre_hook(lambda mod,inp:(inp[0].float(),))
    m.norm.float()
    return m,tok

def pack_case(text,tok,limit=LIMIT):
    tokens=tok(text,add_special_tokens=False,return_attention_mask=False,verbose=False)['input_ids']
    packs=[];seq=[];ends=[];rows=[];prev=[];long=0;dropped=0
    for i,items in enumerate(tokens):
        v=list(items)+[tok.eos_token_id]
        if len(v)>limit:
            long+=1;dropped+=len(v)-limit
            h=limit//2
            v=v[:h]+v[-(limit-h):]
        if len(seq)+len(v)>limit:
            if rows:packs.append((seq,ends,rows))
            n=min(len(prev),OVERLAP,limit-len(v))
            seq=prev[-n:] if n else []
            ends=[];rows=[]
        seq+=v;ends.append(len(seq)-1);rows.append(i)
        prev=v
    if rows:packs.append((seq,ends,rows))
    assert sum(len(x[2]) for x in packs)==len(text)
    return packs,long,dropped

def padded(listed,pad):
    n=max(map(len,listed));n=(n+7)//8*8
    ids=torch.full((len(listed),n),pad,device='cuda',dtype=torch.long)
    mask=torch.zeros_like(ids)
    for i,tokens in enumerate(listed):
        ids[i,:len(tokens)]=torch.tensor(tokens,device='cuda')
        mask[i,:len(tokens)]=1
    return ids,mask

@torch.inference_mode()
def prototypes(m,tok):
    ids=[tok.encode(s,add_special_tokens=False)+[tok.eos_token_id] for s in ROLES]
    x,mask=padded(ids,tok.pad_token_id)
    h=m(x,attention_mask=mask,use_cache=False).last_hidden_state
    out=h[torch.arange(len(ids),device='cuda'),mask.sum(-1)-1].float()
    return torch.nn.functional.normalize(out,dim=-1)

def get_records(src,group):
    with gzip.open(src,'rt') as f:
        return [v for line in f if (v:=json.loads(line))['group']==group]

@torch.inference_mode()
def capture(m,tok,protos,slots,records,group,src):
    lens=[len(x['text']) for x in records]; off=np.r_[0,np.cumsum(lens)]
    specs=[];trunc=lost=0
    for start,rec in zip(off,records):
        packs,a,b=pack_case(rec['text'],tok)
        specs.extend((s,end,[int(start+j) for j in ids]) for s,end,ids in packs)
        trunc+=a;lost+=b
    n=off[-1]
    order=sorted(range(len(specs)),key=lambda i:len(specs[i][0]),reverse=True)
    results={k:np.empty((n,d),np.float16 if k!='raw' else np.float32) for k,d in [('hidden',m.config.hidden_size),('z',len(slots)),('raw',7)]}
    dp=m.layers[-1].mlp.down_proj
    current={}; hooks=[]
    hooks.append(dp.register_forward_pre_hook(lambda mod,inp:current.update(z=inp[0][current['b'],current['t']].index_select(1,slots))))
    hooks.append(m.norm.register_forward_pre_hook(lambda mod,inp:current.update(raw=inp[0][current['b'],current['t']].float())))
    effective=protos * m.norm.weight[None,:]
    collected=np.zeros(n,np.int8)
    start_t=time.time()
    for step in range(0,len(order),BATCH):
        parts=[specs[q] for q in order[step:step+BATCH]]
        ix=np.concatenate([p[2] for p in parts])
        current['b']=torch.tensor(np.repeat(np.arange(len(parts)),[len(p[1]) for p in parts]),device='cuda')
        current['t']=torch.tensor(np.concatenate([p[1] for p in parts]),device='cuda')
        x,mask=padded([p[0] for p in parts],tok.pad_token_id)
        out=m(x,attention_mask=mask,use_cache=False).last_hidden_state
        selected=out[current['b'],current['t']].float()
        results['hidden'][ix]=torch.nn.functional.normalize(selected,dim=1).half().cpu().numpy()
        results['z'][ix]=current['z'].half().cpu().numpy()
        results['raw'][ix]=(current['raw']@effective.T).cpu().numpy()
        collected[ix]+=1
        if step%(BATCH*50)==0: print(group,step,len(specs),round(time.time()-start_t,1),flush=True)
    for hook in hooks:hook.remove()
    assert (collected==1).all() and all(np.isfinite(v).all() for v in results.values())
    stage=HERE/(group+'-features.part');dest=stage.with_suffix('.npz')
    baseline_file=REMOTE/(group+'.npz')
    with np.load(baseline_file,allow_pickle=False) as b:
        np.testing.assert_array_equal(b['case_ids'][:len(records)], [r['case'] for r in records])
        np.testing.assert_array_equal(b['offsets'][:len(off)],off)
        baseline=b['reference'][:off[-1]]
    with stage.open('wb') as f:
        np.savez(f,**results,case_ids=np.array([r['case'] for r in records]),offsets=off,gold=np.concatenate([r['gold'] for r in records]).astype(np.int8),base=baseline)
    stage.replace(dest)
    info=dict(rows=int(n),cases=len(records),packs=len(specs),truncated_sentences=trunc,tokens_dropped=lost,backend=verify_t4(),seconds=time.time()-start_t,
              source_sha256=sha(src),weights_sha256=sha(MODEL/'model.safetensors'),features_sha256=sha(dest))
    (HERE/(group+'-capture.json')).write_text(json.dumps(info,indent=2))
    print('Complete',group,info,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('groups',nargs='*');args=ap.parse_args()
    verify_t4();torch.set_num_threads(1)
    m,tok=load_model();p=prototypes(m,tok)
    slots=np.sort(np.random.default_rng(20261122).choice(m.config.intermediate_size,768,replace=False))
    np.savez(HERE/'metadata.npz',prototypes=p.cpu().numpy(),norm=m.norm.weight.detach().cpu().numpy(),slots=slots)
    slots=torch.tensor(slots,device='cuda')
    src=HERE/'cohorts.jsonl.gz'
    for group in (args.groups or ['fit','select','confirm','fresh']):
        capture(m,tok,p,slots,get_records(src,group),group,src)
if __name__=='__main__':main()
