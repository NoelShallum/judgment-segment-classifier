"""Materialize the low-rank write in Qwen's last MLP. Compare native forwards with the analytical replay."""
import hashlib,json,io
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import numpy as np
import torch
from safetensors.numpy import save_file,load_file
from encode_context import HERE,REMOTE,sha,load_model,get_records,pack_case,padded,verify_t4
from solve import rowcenter
def hsh(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()

@torch.inference_mode()
def main():
    actual=verify_t4();m,tok=load_model()
    with np.load(HERE/'metadata.npz') as f:
        protos=f['prototypes'];norm=f['norm'];slots=f['slots'].copy()
    eff=np.asarray(protos*norm[None,:],dtype=np.float64)
    dual=np.linalg.pinv(eff).astype(np.float32)
    assert np.allclose(eff@dual,np.eye(7),atol=1e-5)
    st=torch.tensor(slots,device='cuda')
    dp=m.layers[-1].mlp.down_proj
    original=dp.weight.detach().clone()
    src=HERE/'cohorts.jsonl.gz'
    packs=[]
    for group in ('select','confirm','fresh'):
        rows=get_records(src,group)
        for j in (0,len(rows)//2,len(rows)-1):
            parts,_,_=pack_case(rows[j]['text'],tok)
            packs.extend(parts[q] for q in sorted({0,len(parts)//2,len(parts)-1}))
    def run():
        coords={};handles=[]
        handles.append(dp.register_forward_pre_hook(lambda mod,inp:coords.update(z=inp[0][coords['b'],coords['t']].index_select(1,st).cpu().numpy())))
        handles.append(m.norm.register_forward_pre_hook(lambda mod,inp:coords.update(h=inp[0][coords['b'],coords['t']].cpu().numpy())))
        heads=[];zs=[]
        for a in range(0,len(packs),8):
            batch=packs[a:a+8];ids,mask=padded([p[0] for p in batch],tok.pad_token_id)
            coords['b']=torch.tensor(np.repeat(np.arange(len(batch)),[len(p[1]) for p in batch]),device='cuda')
            coords['t']=torch.tensor(np.concatenate([p[1] for p in batch]),device='cuda')
            m(ids,attention_mask=mask,use_cache=False)
            heads.append(coords['h']);zs.append(coords['z'])
        for h in handles:h.remove()
        return (np.concatenate(heads)@eff.T).astype(np.float32),np.concatenate(zs)
    original_score,z=run()
    proof=dict(device=actual,weights_sha256=sha(REMOTE/'qwen/model.safetensors'),native_tensor='layers.27.mlp.down_proj.weight',native_source_tensor_sha256=hsh(original.cpu().numpy()),tensor_shape=list(original.shape),packs=len(packs),sentences=len(original_score),variants={})
    for kind in ('full','pair'):
        for suffix in ('','-shuffled'):
            key=kind+suffix;p=load_file(str(HERE/(key+'.safetensors')));coef=p['coef']
            right=coef.T.copy();delta=dual@right
            dp.weight.copy_(original)
            dp.weight[:,st]=original[:,st]+torch.as_tensor(delta,device='cuda')
            guess,z2=run();np.testing.assert_array_equal(z,z2)
            expected=original_score+z@coef
            real=rowcenter(guess);calc=rowcenter(expected);err=float(np.abs(real-calc).max())
            mismatch=int(np.count_nonzero(real.argmax(1)!=calc.argmax(1)))
            if not np.allclose(real,calc,rtol=1e-4,atol=2e-3) or mismatch:raise ValueError((key,err,mismatch))
            other=[1,2,3,4,6]
            path=HERE/(key+'-native-patch.safetensors')
            save_file({'left':dual,'right':right,'slots':slots,'prototypes':protos,'amplitude':p['amplitude']},str(path))
            approx_rank=int(np.linalg.matrix_rank(right,rtol=2e-4))
            proof['variants'][key]=dict(max_logit_error=err,label_mismatches=mismatch,rank=approx_rank,
                                      delta_frobenius=float(np.linalg.norm(delta)),original_frobenius=float(original.norm().item()),
                                      edited_entries=int(torch.count_nonzero(dp.weight-original)),edited_tensor_sha256=hsh(dp.weight.cpu().numpy()),patch_sha256=sha(path),
                                      max_score_change_other_five_before_final_normalization=float(np.abs((guess-original_score)[:,other]).max()))
    (HERE/'native-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
    items=[f for f in HERE.iterdir() if f.is_file() and (f.suffix in {'.safetensors','.py'} or f.name in {'metadata.npz','frozen.json','protocol.json','evaluation.json','native-verification.json'} or f.name.endswith('-predictions.npz') or f.name.endswith('-capture.json'))]
    dest=REMOTE/'context-results.zip';tmp=dest.with_suffix('.part')
    with ZipFile(tmp,'w',ZIP_DEFLATED) as f:
        for p in items:f.write(p,p.name)
        f.writestr('SHA256SUMS.json',json.dumps({p.name:sha(p) for p in items},indent=2))
    tmp.replace(dest);print('Verified',len(original_score),proof['variants'],dest.stat().st_size,sha(dest),flush=True)
if __name__=='__main__':main()
